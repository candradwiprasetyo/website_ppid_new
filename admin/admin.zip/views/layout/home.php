

               

                <!-- Main content -->
                <section class="content">
                    
                    
                     <div class="row">
                     
                     <div class="col-md-12">
                    
                  
                    
                             <div class="box">
                           
                             
                                <div class="box-body2 table-responsive" style="padding:20px; text-align:center;">
                                  <h2>Selamat Datang</h2>
                                  <h4> Di website administrator PPID BPM Prov Jatim </h4><br>
                                  <br />
									<div style="font-size:11px; color:#ccc;">Copyright © 2015, BPM Prov Jatim. All rights reserved. </div>
                                </div><!-- /.box-body -->
                            </div><!-- /.box -->
                       
                        </div>
                        
                         
                        
                    </div>

					 <div class="row">
                      
                        <!-- right column -->
                       
                    </div>   <!-- /.row -->


                </section><!-- /.content -->